/*
 * kmeans_3b_parallel.c
 *
 * An implementation of k-means in C containing a SIMD implementation of kernel 3b which is 
 * parallelized using OpenMP, and naive implementations of the other kernels. 
 * This file also has a dataset that fits the requirements for our SIMD kernels. 
 *
 * Finds k clusters in an input dataset that minimizes the squared euclidean distance 
 * between each pair of points in each cluster.
 *
 * This file has: 
 * - The kmeans function with a SIMD, parallelized kernel 3b
 * - A test with a configurable number of points split into 8 clusters in 8-D space
 *
 * Upon running this file, the main function will run the test and print 
 * the expected outputs and actual outputs, and will also print kernel 3b's 
 * throughput and latency. 
 */

#include "immintrin.h"
#include <float.h>
#include <math.h>
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define CPU_FREQ_SCALE (3.4 / 2.4)

#define BSR(dst, src) {\
    __asm__ __volatile__(\
        "bsr %1, %0\n"\
        : "+r" (dst) \
        : "r" (src));\
}

/*
 * Returns the current number of CPU cycles since reset.
 */
unsigned long long rdtsc() {   
    unsigned a, d;   
    __asm__ volatile("rdtsc" : "=a" (a), "=d" (d));   
    return ((unsigned long long)a) | (((unsigned long long)d) << 32);  
} 

/*
 * Returns the squared Euclidean distance between the m-dimensional points 
 * x and y as a float.
 *
 * Parameters:
 * A is a pointer to a mxn buffer of points, with each column 
 * representing a coordinate of x in m-dimensional space.
 * B is a pointer to a buffer of m floats, with each float 
 * representing a coordinate of y. 
 * n is the number of points in A, 
 * k is the number of points in B, and 
 * m is the number of dimensions.
 * x and y are the indices of the points in A and B to calculate the distance 
 * between.
 *
 * Return values:
 * The squared Euclidean distance between x and y, or 
 * sum of (x_i - y_i) ^ 2 for all i.
 */
float distance(float* A, float* B, int x, int y, int n, int k, int m) {
    float s = 0.0;
    for(int i = 0; i < m; i++) {
        float a = A[n*i + x];
        float b = B[k*i + y];
        s += (a-b)*(a-b);
    }

    return s;
}

/*
 * Gets the index of the most significant set 
 * bit in x.
 *
 * If there are no bits set in x, this function 
 * returns -1.
 */ 
int _bit_scan_reverse(int x) {
    /*for(int i = 31; i >= 0; i--) {
        if((1 << i) & x) {
            return i;    
        }
    }*/

    if(x) {
        BSR(x, x);
        return x;
    }

    return -1;
}

/*
 * Performs k-means clustering on the data and returns k centroids 
 * which best partitions the data into k groups. 
 *
 * Parameters:
 * points is a pointer to an m by n matrix of floats stored in row-major order, where each 
 * column represents a m-dimensional point. The user should allocate at least 
 * mxn floats' worth of space for points.
 *
 * m is the dimensionality of the data, i.e. the number of dimensions of each data point.
 * n is the number of data points in data.
 * k is the number of clusters that k-means should partition the data into.
 * 
 * clusters is a pointer to a m by k matrix of floats, which k-means fills with the k clusters'
 * m-dimensional centroids in row-major order. In the matrix, each column is a m-dimensional point with the 
 * cluster centroid. The user should allocate at least m*k floats' worth of bytes 
 * for clusters.
 *
 * Return values:
 * There are no outputs, but kmeans will modify centroids destructively and 
 * return the k clusters' m-dimensional centroids as column-major floats in the buffer pointed to 
 * by the clusters parameter.
 */
void kmeans(float* points, int n, int m, int k, float* clusters) {
    ////// 1: Initialize clusters

    // Seed the random number generator. 
    srand(time(NULL));
    // Initialize k m-dimensional cluster centers as random points in the dataset.
    for(int cluster = 0; cluster < k; cluster++) {
        // Choose a random point to initialize the cluster as.
        int random_idx = rand() % n;
        for(int i = 0; i < m; i++) {
            clusters[k*i + cluster] = points[n*i + random_idx]; 
        }
    }

    // Stores the distances between each point and cluster. 
    // cluster_point_distances[x][y] represents the distance between cluster x and point y.
    float cluster_point_distances[k * n];
    posix_memalign((void**) &cluster_point_distances, 64, k * n * sizeof(float));

    // Maps each point to its closest cluster.
    // Each value in point_cluster_assignments will be in [0, k), 
    // representing the index of the cluster that the point 
    // is assigned to.
    int point_cluster_assignments[n];
    posix_memalign((void**) &point_cluster_assignments, 64, n * sizeof(int));
        
    // Stores the number of points in each cluster. 
    // Used when calculating the new centroids of each cluster. 
    int num_points_in_cluster[k];
    posix_memalign((void**) &num_points_in_cluster, 64, k * sizeof(int));

    ////// 2: Loop until convergence
    
    unsigned long long time_3b = 0;

    // We loop for 1000 iterations. 
    for(int iter = 0; iter < 1000; iter++) {
        // printf("Iteration %d\n", iter);

        ////// 3: Assign each point to its closest cluster.
        
        //// 3a: Get the distances between each point and cluster.
        for(int pt = 0; pt < n; pt++) {
            for(int cluster = 0; cluster < k; cluster++) {
                float dist = distance(points, clusters, pt, cluster, n, k, m);
                cluster_point_distances[n*cluster + pt] = dist;
            }
        }
       
        // Reset the clusters and numbers of points.
        memset(clusters, 0.0, m*k*sizeof(float));
        memset(num_points_in_cluster, 0, k*sizeof(int));

        //// 3b: Assign the point to its closest cluster.
        unsigned long long st = rdtsc();
        
        #pragma omp parallel num_threads(NUM_THREADS)
        {
            int id = omp_get_thread_num();
            int operations_per_thread = ((n / 8) / NUM_THREADS);

            int starting_iter = id * operations_per_thread;
            int ending_iter = (id + 1) * operations_per_thread;
            if(id == NUM_THREADS - 1) {
                ending_iter = n / 8;
            }

            // Calculate 8 assignments at a time, since a SIMD vector can hold 8 floats.
            for(int i = starting_iter; i < ending_iter; i++) {
                int point = i * 8;

                // A register for loading in a row of 8 points' distances to a cluster.
                __m256 c;

                // Get each point's minimum distance to a cluster. 
                __m256 mins = _mm256_loadu_ps(cluster_point_distances + point);
                c = _mm256_loadu_ps(cluster_point_distances + n*1 + point);
                mins = _mm256_min_ps(mins, c);
                c = _mm256_loadu_ps(cluster_point_distances + n*2 + point);
                mins = _mm256_min_ps(mins, c);
                c = _mm256_loadu_ps(cluster_point_distances + n*3 + point);
                mins = _mm256_min_ps(mins, c);
                c = _mm256_loadu_ps(cluster_point_distances + n*4 + point);
                mins = _mm256_min_ps(mins, c);
                c = _mm256_loadu_ps(cluster_point_distances + n*5 + point);
                mins = _mm256_min_ps(mins, c);
                c = _mm256_loadu_ps(cluster_point_distances + n*6 + point);
                mins = _mm256_min_ps(mins, c);
                c = _mm256_loadu_ps(cluster_point_distances + n*7 + point);
                mins = _mm256_min_ps(mins, c);

                // Compare each point's minimum distance to the distances to each cluster, 
                // and get 8 SIMD vectors, with each representing a cluster and whether 
                // each of the 8 points is closest to it.
                c = _mm256_loadu_ps(cluster_point_distances + n*0 + point);
                __m256 c0 = _mm256_cmp_ps(mins, c, 0);
                c = _mm256_loadu_ps(cluster_point_distances + n*1 + point);
                __m256 c1 = _mm256_cmp_ps(mins, c, 0);
                c = _mm256_loadu_ps(cluster_point_distances + n*2 + point);
                __m256 c2 = _mm256_cmp_ps(mins, c, 0);
                c = _mm256_loadu_ps(cluster_point_distances + n*3 + point);
                __m256 c3 = _mm256_cmp_ps(mins, c, 0);
                c = _mm256_loadu_ps(cluster_point_distances + n*4 + point);
                __m256 c4 = _mm256_cmp_ps(mins, c, 0);
                c = _mm256_loadu_ps(cluster_point_distances + n*5 + point);
                __m256 c5 = _mm256_cmp_ps(mins, c, 0);
                c = _mm256_loadu_ps(cluster_point_distances + n*6 + point);
                __m256 c6 = _mm256_cmp_ps(mins, c, 0);
                c = _mm256_loadu_ps(cluster_point_distances + n*7 + point);
                __m256 c7 = _mm256_cmp_ps(mins, c, 0);

                // Transpose it to get 8 SIMD vectors, with each representing a point and 
                // whether each cluster is cloest to it.
                __m256 tmp0 = _mm256_shuffle_ps(c0, c1, \
                        (0 << 0) | (2 << 2) | (0 << 4) | (2 << 6));
                tmp0 = _mm256_permute_ps(tmp0, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));
                __m256 tmp1 = _mm256_shuffle_ps(c0, c1, \
                        (1 << 0) | (3 << 2) | (1 << 4) | (3 << 6));
                tmp1 = _mm256_permute_ps(tmp1, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));
                
                __m256 tmp2 = _mm256_shuffle_ps(c2, c3, \
                        (0 << 0) | (2 << 2) | (0 << 4) | (2 << 6));
                tmp2 = _mm256_permute_ps(tmp2, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));
                __m256 tmp3 = _mm256_shuffle_ps(c2, c3, \
                        (1 << 0) | (3 << 2) | (1 << 4) | (3 << 6));
                tmp3 = _mm256_permute_ps(tmp3, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));
                
                __m256 tmp4 = _mm256_shuffle_ps(c4, c5, \
                        (0 << 0) | (2 << 2) | (0 << 4) | (2 << 6));
                tmp4 = _mm256_permute_ps(tmp4, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));
                __m256 tmp5 = _mm256_shuffle_ps(c4, c5, \
                        (1 << 0) | (3 << 2) | (1 << 4) | (3 << 6));
                tmp5 = _mm256_permute_ps(tmp5, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));

                __m256 tmp6 = _mm256_shuffle_ps(c6, c7, \
                        (0 << 0) | (2 << 2) | (0 << 4) | (2 << 6));
                tmp6 = _mm256_permute_ps(tmp6, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));
                __m256 tmp7 = _mm256_shuffle_ps(c6, c7, \
                        (1 << 0) | (3 << 2) | (1 << 4) | (3 << 6));
                tmp7 = _mm256_permute_ps(tmp7, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));

                c0 = _mm256_shuffle_ps(tmp0, tmp2, (0 << 0) | (1 << 2) | (0 << 4) | (1 << 6));
                c1 = _mm256_shuffle_ps(tmp1, tmp3, (0 << 0) | (1 << 2) | (0 << 4) | (1 << 6));
                c2 = _mm256_shuffle_ps(tmp0, tmp2, (2 << 0) | (3 << 2) | (2 << 4) | (3 << 6));
                c3 = _mm256_shuffle_ps(tmp1, tmp3, (2 << 0) | (3 << 2) | (2 << 4) | (3 << 6));

                c4 = _mm256_shuffle_ps(tmp4, tmp6, (0 << 0) | (1 << 2) | (0 << 4) | (1 << 6));
                c5 = _mm256_shuffle_ps(tmp5, tmp7, (0 << 0) | (1 << 2) | (0 << 4) | (1 << 6));
                c6 = _mm256_shuffle_ps(tmp4, tmp6, (2 << 0) | (3 << 2) | (2 << 4) | (3 << 6));
                c7 = _mm256_shuffle_ps(tmp5, tmp7, (2 << 0) | (3 << 2) | (2 << 4) | (3 << 6));

                tmp0 = _mm256_permute2f128_ps(c0, c4, (0 << 0) | (2 << 4));
                tmp1 = _mm256_permute2f128_ps(c1, c5, (0 << 0) | (2 << 4));
                tmp2 = _mm256_permute2f128_ps(c2, c6, (0 << 0) | (2 << 4));
                tmp3 = _mm256_permute2f128_ps(c3, c7, (0 << 0) | (2 << 4));

                tmp4 = _mm256_permute2f128_ps(c0, c4, (1 << 0) | (3 << 4));
                tmp5 = _mm256_permute2f128_ps(c1, c5, (1 << 0) | (3 << 4));
                tmp6 = _mm256_permute2f128_ps(c2, c6, (1 << 0) | (3 << 4));
                tmp7 = _mm256_permute2f128_ps(c3, c7, (1 << 0) | (3 << 4));

                // Move each of the point-cluster SIMD vectors into an int 
                // that has the bottom eight bytes set to a 1 or 0, with 1 
                // being that the cluster is the min cluster.
                int mask0 = _mm256_movemask_ps(tmp0);
                int mask1 = _mm256_movemask_ps(tmp1);
                int mask2 = _mm256_movemask_ps(tmp2);
                int mask3 = _mm256_movemask_ps(tmp3);
                int mask4 = _mm256_movemask_ps(tmp4);
                int mask5 = _mm256_movemask_ps(tmp5);
                int mask6 = _mm256_movemask_ps(tmp6);
                int mask7 = _mm256_movemask_ps(tmp7);

                // Use _bit_scan_reverse to get the index of the set bit for each 
                // point. This index represents the cluster that's the closest to the 
                // point.
                int assignment0 = _bit_scan_reverse(mask0);
                int assignment1 = _bit_scan_reverse(mask1);
                int assignment2 = _bit_scan_reverse(mask2);
                int assignment3 = _bit_scan_reverse(mask3);
                int assignment4 = _bit_scan_reverse(mask4);
                int assignment5 = _bit_scan_reverse(mask5);
                int assignment6 = _bit_scan_reverse(mask6);
                int assignment7 = _bit_scan_reverse(mask7);

                // Assign each point to its closest cluster and update the cluster's 
                // number of points.
                point_cluster_assignments[point + 0] = assignment0;
                point_cluster_assignments[point + 1] = assignment1;
                point_cluster_assignments[point + 2] = assignment2;
                point_cluster_assignments[point + 3] = assignment3;
                point_cluster_assignments[point + 4] = assignment4;
                point_cluster_assignments[point + 5] = assignment5;
                point_cluster_assignments[point + 6] = assignment6;
                point_cluster_assignments[point + 7] = assignment7;

                #pragma omp atomic
                num_points_in_cluster[assignment0]++;
                #pragma omp atomic
                num_points_in_cluster[assignment1]++;
                #pragma omp atomic
                num_points_in_cluster[assignment2]++;
                #pragma omp atomic
                num_points_in_cluster[assignment3]++;
                #pragma omp atomic
                num_points_in_cluster[assignment4]++;
                #pragma omp atomic
                num_points_in_cluster[assignment5]++;
                #pragma omp atomic
                num_points_in_cluster[assignment6]++;
                #pragma omp atomic
                num_points_in_cluster[assignment7]++;
            }
        }
        
        unsigned long long et = rdtsc();
        time_3b += et - st;
       
        ////// 4: Update each cluster's centroid to the mean of all points assigned to it.
        
        // To do this in O(n), we can simply loop through the points 
        // and get a running sum of each cluster's coordinates, and then divide 
        // each coordinate by the final numbers of points for each cluster to 
        // get the mean for each cluster. 
        
        //// 4a: Get the sum of points for each cluster.
        for(int pt = 0; pt < n; pt++) {
            // Figure out which cluster the point is in.
            int cluster = point_cluster_assignments[pt];
            // Update that cluster's sum of coordinates with this point.
            for(int i = 0; i < m; i++) {
                clusters[k*i + cluster] += points[n*i + pt];
            }
        }

        //// 4b: Divide the sum of points for each cluster by the number of points in the cluster 
        // to get the average of the points in the cluster (the centroid). 
        // Assign each cluster to be its average.
        for(int cluster = 0; cluster < k; cluster++) {
            // If the cluster has points in it then its mean becomes the average of the points.
            if(num_points_in_cluster[cluster] > 0) {
                for(int i = 0; i < m; i++) {
                    clusters[k*i + cluster] = clusters[k*i + cluster] / num_points_in_cluster[cluster];
                }
            } else {
                // If the cluster doesn't have points in it then initialize it randomly again.
                int random_idx = rand() % n;
                for(int i = 0; i < m; i++) {
                    clusters[k*i + cluster] = points[n*i + random_idx]; 
                }
            }
        } 
    }
   
    /*
     * Each inner loop iteration does k mins to get the minimum distances for each point, 
     * k cmps to get the 0-1 mask of point assignments, 4*k shuffles and permutes for the transpose, 
     * and k movemask SIMD instructions in the cluster-point distances. 
     * This means there are 7*k SIMD operations = 8*7*k float operations done by 3b per loop iteration. 
     * There are n/8 loops of this, so the overall FLOPs done by 3b per iteration is (n/8)*(8*7*k) = 7*n*k.
     */
    printf("Average cycles taken total on kernel 3b: %f\n", CPU_FREQ_SCALE * ((float) (time_3b) / 1000.0));
    printf("Throughput in kernel 3b: %f\n", (7*n*k) / (CPU_FREQ_SCALE * ((float) (time_3b) / 1000.0)));
}


/*
 * Test k-means with num_of_data 8-D points. The num_of_data points will be spread out randomly with low variance 
 * across eight clusters: (i,i,i,i,i,i,i,i) for i in [0...7]. 
 *
 * Note that num_of_data must be a multiple of 8, as it is spread evenly across the eight clusters. 
 *
 * The input parameter add_noise specifies whether to add noise to the datapoints. If add_noise is 
 * true then the datapoints will be uniformly spread about each cluster between 0.0 and 0.5 
 * Euclidean distance away.
 */
void test_8D(int add_noise, int num_of_data) {
    int n = num_of_data; 
    int m = 8;
    int k = 8;

    printf("Basic test with 8-D points:\n");
    if(add_noise) {
        printf("There is noise added. The clusters should be roughly all 0s to all 7s, but there might be some clusters that are both around the same center.\n");
    } else {
        printf("There is no noise added. The clusters should be all 0s to all 7s, in some order.\n");
    }

    // Allocate n*8 floats for the 8xn dataset.
    float data[n*m]; 
    posix_memalign((void **) &data, n, n * m * sizeof(float));

    // Generate 8 points uniformly randomly up to a Euclidean distance of 0.5 
    // from each of the 8 clusters.
    for(int cluster = 0; cluster < 8; cluster++) {
        for(int pt = 0; pt < num_of_data/8; pt++) {
            // Each point needs to be stored as a column. 
            for(int dim = 0; dim < 8; dim++) {
                // Add noise to the point to make it differ from the cluster center 
                // as much as 0.5.
                float noise = 0.0; 
                if(add_noise) {
                    noise = (((float) (rand() % 50)) / 100.0);   
                }
                // Choose uniformly randomly to add or subtract noise.
                if(rand() % 2) noise *= -1;

                data[dim*n + cluster*num_of_data/8 + pt] = cluster + noise;
            }
        }
    }

    // Allocate space for 8 centroids.
    float clusters[8*8];
    posix_memalign((void **) &clusters, n, 8 * 8 * sizeof(float));

    // Note that I'm passing stack-allocated memory, but we're guaranteed 
    // that data and centroids are valid memory for the duration of kmeans, 
    // since we're calling kmeans and know its memory guarantees.
    kmeans(data, n, 8, 8, clusters);

    // Print the centroids. They could be in any order, but should be the eight original clusters.
    printf("\tThe centroids should be around (0,0,0,0,0,0,0,0) to (7,7,7,7,7,7,7,7).\n");
    for(int cluster = 0; cluster < 8; cluster++) {
        printf("\tThe %dth centroid is (", cluster+1);
        for(int dim = 0; dim < m; dim++) {
            printf("%f,", clusters[k*dim+cluster]);
        }
        printf(")\n");
    }

    printf("Test completed.\n");
}

int main() {
    // number of data points
    int num_of_data = 56000;
    printf("Testing k-means. Note that since k-means initializes clusters randomly, it might return incorrect clusters sometimes.\n");
    unsigned long long st = rdtsc();
    test_8D(0, num_of_data);
    unsigned long long et = rdtsc();
    
    
    printf("Cycles taken total on the %d 8-D points example: %f\n", num_of_data, CPU_FREQ_SCALE * (float) (et - st));
    
    return 0;
}
