/*
 * kmeans_unoptimized.c
 *
 * A baseline implementation of naive k-means in C. 
 * Finds k clusters in an input dataset that minimizes the squared euclidean distance 
 * between each pair of points in each cluster.
 *
 * This file has: 
 * - The baseline kmeans function
 * - A basic test with 2-D input data from the scikit-learn documentation
 * - A basic test with 4-D input data that should form two distinct clusters
 *
 * Upon running this file, the main function will run both tests and print 
 * the expected outputs and actual outputs, and will also print the elapsed cycles 
 * that k-means took when doing each test.
 */

#include <time.h>
#include <float.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CPU_FREQ_SCALE (3.4 / 2.4)

/*
 * Returns the current number of CPU cycles since reset.
 */
unsigned long long rdtsc() {   
    unsigned a, d;   
    __asm__ volatile("rdtsc" : "=a" (a), "=d" (d));   
    return ((unsigned long long)a) | (((unsigned long long)d) << 32);  
} 

/*
 * Returns the squared Euclidean distance between the m-dimensional points 
 * x and y as a float.
 *
 * Parameters:
 * A is a pointer to a mxn buffer of points, with each column 
 * representing a coordinate of x in m-dimensional space.
 * B is a pointer to a buffer of m floats, with each float 
 * representing a coordinate of y. 
 * n is the number of points in A, 
 * k is the number of points in B, and 
 * m is the number of dimensions.
 * x and y are the indices of the points in A and B to calculate the distance 
 * between.
 *
 * Return values:
 * The squared Euclidean distance between x and y, or 
 * sum of (x_i - y_i) ^ 2 for all i.
 */
float distance(float* A, float* B, int x, int y, int n, int k, int m) {
    float s = 0.0;
    for(int i = 0; i < m; i++) {
        float a = A[n*i + x];
        float b = B[k*i + y];
        s += (a-b)*(a-b);
    }

    return s;
}


/*
 * Performs k-means clustering on the data and returns k centroids 
 * which best partitions the data into k groups. 
 *
 * Parameters:
 * points is a pointer to an m by n matrix of floats stored in row-major order, where each 
 * column represents a m-dimensional point. The user should allocate at least 
 * mxn floats' worth of space for points.
 *
 * m is the dimensionality of the data, i.e. the number of dimensions of each data point.
 * n is the number of data points in data.
 * k is the number of clusters that k-means should partition the data into.
 * 
 * clusters is a pointer to a m by k matrix of floats, which k-means fills with the k clusters'
 * m-dimensional centroids in row-major order. In the matrix, each column is a m-dimensional point with the 
 * cluster centroid. The user should allocate at least m*k floats' worth of bytes 
 * for clusters.
 *
 * Return values:
 * There are no outputs, but kmeans will modify centroids destructively and 
 * return the k clusters' m-dimensional centroids as column-major floats in the buffer pointed to 
 * by the clusters parameter.
 */
void kmeans(float* points, int n, int m, int k, float* clusters) {
    ////// 1: Initialize clusters

    // Seed the random number generator. 
    srand(time(NULL));
    // Initialize k m-dimensional cluster centers as random points in the dataset.
    for(int cluster = 0; cluster < k; cluster++) {
        // Choose a random point to initialize the cluster as.
        int random_idx = rand() % n;
        for(int i = 0; i < m; i++) {
            clusters[k*i + cluster] = points[n*i + random_idx]; 
        }
    }

    // Stores the distances between each point and cluster. 
    // d[x][y] represents the distance between point x and cluster y.
    float point_cluster_distances[k * n];

    // Maps each point to its closest cluster.
    // Each value in point_cluster_assignments will be in [0, k), 
    // representing the index of the cluster that the point 
    // is assigned to.
    int point_cluster_assignments[n];
        
    // Stores the number of points in each cluster. 
    // Used when calculating the new centroids of each cluster. 
    int num_points_in_cluster[k];

    ////// 2: Loop until convergence

    // We loop for 1000 iterations. 
    for(int iter = 0; iter < 1000; iter++) {
        // printf("Iteration %d\n", iter);

        ////// 3: Assign each point to its closest cluster.
        
        //// 3a: Get the distances between each point and cluster.
        for(int pt = 0; pt < n; pt++) {
            for(int cluster = 0; cluster < k; cluster++) {
                float dist = distance(points, clusters, pt, cluster, n, k, m);
                point_cluster_distances[n*cluster + pt] = dist;
            }
        }
       
        // Reset the clusters and numbers of points.
        memset(clusters, 0.0, m*k*sizeof(float));
        memset(num_points_in_cluster, 0, k*sizeof(int));

        //// 3b: Assign the point to its closest cluster.
        for(int pt = 0; pt < n; pt++) {
            // Check each cluster and see which one is the closest.
            int closest_cluster = -1;
            float best_distance = DBL_MAX;
            for(int cluster = 0; cluster < k; cluster++) {
                if(point_cluster_distances[n*cluster + pt] < best_distance) {
                    best_distance = point_cluster_distances[n*cluster + pt];
                    closest_cluster = cluster;
                }
            }

            // Assign the closest cluster to the point. 
            point_cluster_assignments[pt] = closest_cluster;
            // Update that cluster's number of points.
            num_points_in_cluster[closest_cluster]++;
            /*printf("Point (%lf, %lf) is closest to cluster %d at (%lf, %lf) with a distance of %lf\n", points[n*0+pt], points[n*1+pt], \
                    closest_cluster, clusters[k*0+closest_cluster], clusters[k*1+closest_cluster+1], best_distance);
            printf("point_cluster_assignments[%d] = %d\n", pt, point_cluster_assignments[pt]);*/
        }

        ////// 4: Update each cluster's centroid to the mean of all points assigned to it.
        
        // To do this in O(n), we can simply loop through the points 
        // and get a running sum of each cluster's coordinates, and then divide 
        // each coordinate by the final numbers of points for each cluster to 
        // get the mean for each cluster. 
        
        //// 4a: Get the sum of points for each cluster.
        for(int pt = 0; pt < n; pt++) {
            // Figure out which cluster the point is in.
            int cluster = point_cluster_assignments[pt];
            // Update that cluster's sum of coordinates with this point.
            for(int i = 0; i < m; i++) {
                clusters[k*i + cluster] += points[n*i + pt];
            }
        }

        //// 4b: Divide the sum of points for each cluster by the number of points in the cluster 
        // to get the average of the points in the cluster (the centroid). 
        // Assign each cluster to be its average.
        for(int cluster = 0; cluster < k; cluster++) {
            // If the cluster has points in it then its mean becomes the average of the points.
            if(num_points_in_cluster[cluster] > 0) {
                for(int i = 0; i < m; i++) {
                    clusters[k*i + cluster] = clusters[k*i + cluster] / num_points_in_cluster[cluster];
                }
            } else {
                // If the cluster doesn't have points in it then initialize it randomly again.
                int random_idx = rand() % n;
                for(int i = 0; i < m; i++) {
                    clusters[k*i + cluster] = points[n*i + random_idx]; 
                }
            }
        }
        
        /*for(int i = 0; i < k; i++) {
            printf("Centroid %d has %d points in it with sums of (%lf, %lf).\n", i, num_points_in_cluster[i], \
                    cluster_coordinate_sums[m*i], cluster_coordinate_sums[m*i+1]);
            printf("Centroid %d is (%lf,%lf).\n", i, centroids[m*i], centroids[m*i+1]);
        }*/
    }
}


/*
 * Test k-means with 6 2-D points. The test dataset is illustrated in the 
 * scikit-learn k-means documentation, at 
 * https://scikit-learn.org/stable/modules/generated/sklearn.cluster.KMeans.html 
 */
void test_basic() {
    printf("Basic test on the sklearn toy dataset:\n");
    // Allocate 12 floats for the dataset.
    float data[12]; 
    data[0] = 1.0;
    data[1] = 1.0;
    data[2] = 1.0;
    data[3] = 10.0;
    data[4] = 10.0;
    data[5] = 10.0;
    data[6] = 2.0;
    data[7] = 4.0;
    data[8] = 0.0;
    data[9] = 2.0;
    data[10] = 4.0;
    data[11] = 0.0;

    // Allocate space for 2 centroids.
    float clusters[4];

    // Note that I'm passing stack-allocated memory, but we're guaranteed 
    // that data and centroids are valid memory for the duration of kmeans, 
    // since we're calling kmeans and know its memory guarantees.
    kmeans(data, 6, 2, 2, clusters);

    // Print the centroids. They could be in any order, but should be (10, 2) and (1, 2).
    printf("\tThe centroids should be (10,2) and (1,2).\n");
    printf("\tThe first centroid is (%lf,%lf).\n", clusters[0], clusters[2]);
    printf("\tThe second centroid is (%lf,%lf).\n", clusters[1], clusters[3]);
    printf("Basic test completed.\n");
}

/*
 * Test k-means with 5 4-D points. Has three points as a cluster near (1,1,1,1) and two as a cluster near (5,5,5,5).
 */
void test_4D() {
    printf("4-D test:\n");
    // Allocate 20 floats for the dataset.
    float data[5 * 4]; 
    data[0] = 1.0;
    data[1] = 0.8;
    data[2] = 1.2;
    data[3] = 5.2;
    data[4] = 4.8;
    data[5] = 1.1;
    data[6] = 0.9;
    data[7] = 0.7;
    data[8] = 5.1;
    data[9] = 4.7;
    data[10] = 0.8;
    data[11] = 0.9;
    data[12] = 1.2;
    data[13] = 4.2;
    data[14] = 5.8;
    data[15] = 0.2;
    data[16] = 0.8;
    data[17] = 1.0;
    data[18] = 5.0;
    data[19] = 5.1;

    // Allocate space for 2 4-dimensional centroids.
    float centroids[2 * 4];

    // Note that I'm passing stack-allocated memory, but we're guaranteed 
    // that data and centroids are valid memory for the duration of kmeans, 
    // since we're calling kmeans and know its memory guarantees.
    kmeans(data, 5, 4, 2, centroids);

    // Print the centroids. They could be in any order, but should be (10, 2) and (1, 2).
    printf("\tThe centroids should be around (1,1,1,1) and (5,5,5,5).\n");
    printf("\tThe first centroid is (%lf,%lf,%lf,%lf).\n", centroids[0], centroids[2], centroids[4], centroids[6]);
    printf("\tThe second centroid is (%lf,%lf,%lf,%lf).\n", centroids[1], centroids[3], centroids[5], centroids[7]);
    printf("4D test completed.\n");
}

/*
 * Test the Euclidean distance function.
 */
void test_distance() {
    float pt1[2];
    float pt2[2];
    pt1[0] = 1.0;
    pt1[1] = 5.0;
    pt2[0] = 2.0;
    pt2[1] = 6.0;
    printf("The distance between (1,5) and (2,6) should be around 2.\n");
    printf("The distance is: %lf\n", distance(pt1, pt2, 0, 0, 1, 1, 2));
}

int main() {
    /*printf("Testing Euclidean distance...\n");
    test_distance();*/
    printf("Testing unoptimized k-means. Note that since k-means initializes clusters randomly, it might return incorrect clusters sometimes.\n");
    unsigned long long st = rdtsc();
    test_basic();
    unsigned long long et = rdtsc();
    
    printf("Cycles taken total on the sklearn example: %f\n", CPU_FREQ_SCALE * (float) (et - st));
    
    st = rdtsc();
    test_4D();
    et = rdtsc();
    
    printf("Cycles taken total on the 4D example: %f\n", CPU_FREQ_SCALE * (float) (et - st));

    printf("...tests done.\n");

    return 0;
}
