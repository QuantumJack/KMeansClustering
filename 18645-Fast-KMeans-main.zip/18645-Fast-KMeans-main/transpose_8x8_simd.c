#include "immintrin.h"
#include <float.h>
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/*
 * Transposes the 8x8 matrix of floats A and 
 * stores the transposed matrix in B. Destructively 
 * modifies B.
 *
 * A and B should be non-overlapping pointers and both 
 * have at least 64 floats of 
 * space allocated, otherwise this function has 
 * undefined behavior, likely leading to a segmentation 
 * fault. 
 *
 * The underlying transpose is a divide-and-conquer algorithm: 
 * since the input matrix is 8x8, we can hardcode the actual 
 * divide-and-conquer and make it 3 hardcoded steps.
 *
 * This function transposes by swapping the reverse diagonal 
 * submatrices over and over, illustrated by the diagram below:
 *   -----       -----
 *   |A|B|       |A|C|
 *   ----- ====> ----- 
 *   |C|D|       |B|D|
 *   -----       -----
 *
 * First, the function does the swap for every 2x2 matrix within the 
 * 8x8 matrix. It swaps the reverse diagonal 1x1 blocks in each 2x2 matrix. 
 *
 * Then, it swaps the 2x2 reverse diagonal blocks in each 4x4 matrix, 
 * and then the reverse diagonal 4x4 blocks in the overall 8x8 matrix. 
 *
 * This function will load each row of A into a 256-bit input vector, 
 * and then:
 * - For step 1, the function does shuffles and permutes between each 
 *   pair of SIMD vectors- effectively doing the swaps for 4 2x2 blocks 
 *   at a time.
 * - For step 2, the function does shuffles between each half of 4 SIMD 
 *   vectors- effectively doing the swaps for 2 4x4 blocks 
 *   at a time.
 * - For step 4, the function does permute2f128s to swap the two 4x4 blocks 
 *   in the overall 8x8 matrix to complete the transpose. 
 */
void transpose(float* A, float* B) {
    int N = 8;

    __m256 src0 = _mm256_load_ps(A + 0*N);
    __m256 src1 = _mm256_load_ps(A + 1*N);
    __m256 src2 = _mm256_load_ps(A + 2*N);
    __m256 src3 = _mm256_load_ps(A + 3*N);
    __m256 src4 = _mm256_load_ps(A + 4*N);
    __m256 src5 = _mm256_load_ps(A + 5*N);
    __m256 src6 = _mm256_load_ps(A + 6*N);
    __m256 src7 = _mm256_load_ps(A + 7*N);

    //// PART 1: Transpose by 1x1 blocks by doing a shuffle and permute 
    //// on groups of 2 SIMD vectors (which will have 4 2x2 blocks that need 
    //// their reverse 1x1-block diagonals swapped).
    __m256 tmp0 = _mm256_shuffle_ps(src0, src1, \
            (0 << 0) | (2 << 2) | (0 << 4) | (2 << 6));
    tmp0 = _mm256_permute_ps(tmp0, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));
    __m256 tmp1 = _mm256_shuffle_ps(src0, src1, \
            (1 << 0) | (3 << 2) | (1 << 4) | (3 << 6));
    tmp1 = _mm256_permute_ps(tmp1, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));
    
    __m256 tmp2 = _mm256_shuffle_ps(src2, src3, \
            (0 << 0) | (2 << 2) | (0 << 4) | (2 << 6));
    tmp2 = _mm256_permute_ps(tmp2, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));
    __m256 tmp3 = _mm256_shuffle_ps(src2, src3, \
            (1 << 0) | (3 << 2) | (1 << 4) | (3 << 6));
    tmp3 = _mm256_permute_ps(tmp3, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));
    
    __m256 tmp4 = _mm256_shuffle_ps(src4, src5, \
            (0 << 0) | (2 << 2) | (0 << 4) | (2 << 6));
    tmp4 = _mm256_permute_ps(tmp4, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));
    __m256 tmp5 = _mm256_shuffle_ps(src4, src5, \
            (1 << 0) | (3 << 2) | (1 << 4) | (3 << 6));
    tmp5 = _mm256_permute_ps(tmp5, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));

    __m256 tmp6 = _mm256_shuffle_ps(src6, src7, \
            (0 << 0) | (2 << 2) | (0 << 4) | (2 << 6));
    tmp6 = _mm256_permute_ps(tmp6, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));
    __m256 tmp7 = _mm256_shuffle_ps(src6, src7, \
            (1 << 0) | (3 << 2) | (1 << 4) | (3 << 6));
    tmp7 = _mm256_permute_ps(tmp7, (0 << 0) | (2 << 2) | (1 << 4) | (3 << 6));

    //// PART 2: Transpose by 2x2 blocks by doing a shuffle to swap the 
    //// reverse diagonal 2x2 blocks.
    src0 = _mm256_shuffle_ps(tmp0, tmp2, (0 << 0) | (1 << 2) | (0 << 4) | (1 << 6));
    src1 = _mm256_shuffle_ps(tmp1, tmp3, (0 << 0) | (1 << 2) | (0 << 4) | (1 << 6));
    src2 = _mm256_shuffle_ps(tmp0, tmp2, (2 << 0) | (3 << 2) | (2 << 4) | (3 << 6));
    src3 = _mm256_shuffle_ps(tmp1, tmp3, (2 << 0) | (3 << 2) | (2 << 4) | (3 << 6));

    src4 = _mm256_shuffle_ps(tmp4, tmp6, (0 << 0) | (1 << 2) | (0 << 4) | (1 << 6));
    src5 = _mm256_shuffle_ps(tmp5, tmp7, (0 << 0) | (1 << 2) | (0 << 4) | (1 << 6));
    src6 = _mm256_shuffle_ps(tmp4, tmp6, (2 << 0) | (3 << 2) | (2 << 4) | (3 << 6));
    src7 = _mm256_shuffle_ps(tmp5, tmp7, (2 << 0) | (3 << 2) | (2 << 4) | (3 << 6));

    //// PART 3: Transpose by 4x4 blocks and swap the reverse diagonal 4x4 blocks 
    //// the overall matrix.
    tmp0 = _mm256_permute2f128_ps(src0, src4, (0 << 0) | (2 << 4));
    tmp1 = _mm256_permute2f128_ps(src1, src5, (0 << 0) | (2 << 4));
    tmp2 = _mm256_permute2f128_ps(src2, src6, (0 << 0) | (2 << 4));
    tmp3 = _mm256_permute2f128_ps(src3, src7, (0 << 0) | (2 << 4));

    tmp4 = _mm256_permute2f128_ps(src0, src4, (1 << 0) | (3 << 4));
    tmp5 = _mm256_permute2f128_ps(src1, src5, (1 << 0) | (3 << 4));
    tmp6 = _mm256_permute2f128_ps(src2, src6, (1 << 0) | (3 << 4));
    tmp7 = _mm256_permute2f128_ps(src3, src7, (1 << 0) | (3 << 4));

    // Store the transposed matrix into B.
    _mm256_store_ps(B + 0*N, tmp0);
    _mm256_store_ps(B + 1*N, tmp1);
    _mm256_store_ps(B + 2*N, tmp2);
    _mm256_store_ps(B + 3*N, tmp3);
    _mm256_store_ps(B + 4*N, tmp4);
    _mm256_store_ps(B + 5*N, tmp5);
    _mm256_store_ps(B + 6*N, tmp6);
    _mm256_store_ps(B + 7*N, tmp7);
}


/*
 * Test the 8x8 transpose function with a very readable matrix.
 *
 * Input matrix:
 * 0 1 2 ... 7
 * 0 1 2 ... 7
 * ...
 * 0 1 2 ... 7
 */
void test_basic() {
    printf("Running the basic transpose test...\n");
    
    float A[8*8*sizeof(float)];
    float B[8*8*sizeof(float)];

    printf("The original matrix is:\n");
    for(int i = 0; i < 8; i++) {
        for(int j = 0; j < 8; j++) {
            A[8*i + j] = 0.0 + j;
            printf("%f ", A[8*i + j]);
        }
        printf("\n");
    }

    transpose(A, B);

    bool correct = true;
    
    printf("The transposed matrix is:\n");
    for(int i = 0; i < 8; i++) {
        for(int j = 0; j < 8; j++) {
            printf("%f ", B[8*i + j]);
            if(B[8*i + j] != A[8*j + i]) {
                correct = false;
            }
        }
        printf("\n");
    }

    if(correct) {
        printf("...test passed!\n\n");
    }
    else {
        printf("...test failed.\n\n");
    }
}

/*
 * Test the 8x8 transpose function with a random matrix.
 */
void test_random() {
    printf("Running the random transpose test...\n");
    
    float A[8*8*sizeof(float)];
    float B[8*8*sizeof(float)];

    for(int i = 0; i < 8; i++) {
        for(int j = 0; j < 8; j++) {
            A[8*i + j] = 0.0 + j;
        }
    }

    transpose(A, B);

    bool correct = true;
    
    for(int i = 0; i < 8; i++) {
        for(int j = 0; j < 8; j++) {
            if(B[8*i + j] != A[8*j + i]) {
                correct = false;
            }
        }
    }

    if(correct) {
        printf("...test passed!\n\n");
    }
    else {
        printf("...test failed.\n\n");
    }
}


int main() {
    printf("Running tests...\n");

    test_basic();
    test_random();

    printf("Tests complete.\n");

    return 0;
}
