/*
 * kmeans_unoptimized_kernels_timed.c
 *
 * A baseline implementation of naive k-means in C which also records the 
 * latency and throughput each of the four "kernels" within the function.
 *
 * See the comments in the code and the design doc for more info on the kernels.
 *
 * This file has: 
 * - The baseline kmeans function with timers
 * - A basic test with 2-D input data from the scikit-learn documentation
 * - A basic test with 4-D input data that should form two distinct clusters
 *
 * Upon running this file, the main function will run the first test and 
 * print out the average latency (cycles) and throughput (FLOPs per cycle) 
 * of each kernel. 
 */

#include <time.h>
#include <float.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CPU_FREQ_SCALE (3.4 / 2.4)

/*
 * Returns the current number of CPU cycles since reset.
 */
unsigned long long rdtsc() {   
    unsigned a, d;   
    __asm__ volatile("rdtsc" : "=a" (a), "=d" (d));   
    return ((unsigned long long)a) | (((unsigned long long)d) << 32);  
} 

/*
 * Returns the squared Euclidean distance between the m-dimensional points 
 * x and y as a float. 
 *
 * Parameters:
 * x is a pointer to a buffer of m floats, with each float 
 * representing a coordinate of x. 
 * y is a pointer to a buffer of m floats, with each float 
 * representing a coordinate of y. 
 * m is the number of floats that are allocated for x and y.
 *
 * Return values:
 * The squared Euclidean distance between x and y, or 
 * sum of (x_i - y_i) ^ 2 for all i.
 */
float distance(float* x, float* y, int m) {
    float s = 0.0;
    for(int i = 0; i < m; i++) {
        float a = x[i];
        float b = y[i];
        s += (a-b)*(a-b);
    }

    return s;
}


/*
 * Performs k-means clustering on the data and returns k centroids 
 * which best partitions the data into k groups. 
 *
 * Parameters:
 * data is a pointer to an n by m matrix of floats stored in row-major order, where each 
 * row represents a m-dimensional point. The user should allocate at least 
 * nxm floats' worth of space for the data.
 *
 * n is the number of data points in data.
 * m is the dimensionality of the data, i.e. the number of dimensions of each data point.
 * k is the number of clusters that k-means should partition the data into.
 * 
 * centroids is a pointer to a k by m matrix of floats, which k-means fills with the k clusters'
 * m-dimensional centroids. The user should allocate at least k*m floats' worth of bytes 
 * for centroids.
 *
 * Return values:
 * There are no outputs, but kmeans will modify centroids destructively and 
 * return the k clusters' centroids as contiguous floats in the buffer pointed to 
 * by the centroids parameter.
 */
void kmeans(float* data, int n, int m, int k, float* centroids) {
    // Seed the random number generator. 
    srand(time(NULL));
    // Initialize k m-dimensional cluster centers as random points in the dataset.
    for(int cluster = 0; cluster < k; cluster++) {
        // Choose a random point to initialize the cluster as.
        int random_idx = rand() % n;
        for(int i = 0; i < m*k; i++) {
            centroids[i] = data[m*random_idx + i]; 
        }
    }

    // Stores the distances between each point and cluster. 
    // d[x][y] represents the distance between point x and cluster y.
    float distances[n * k];

    // Maps each point to its closest cluster.
    // Each value in point_to_cluster will be in [0, k), 
    // representing the index of the cluster that the point 
    // is assigned to.
    int point_to_cluster[n];
        
    // Stores the running sums of each cluster's points 
    // to calculate the mean coordinate in linear time. 
    float cluster_coordinate_sums[k * m];
    // Stores the number of points in each cluster. 
    // Used when calculating the new centroids of each cluster. 
    int num_points_in_cluster[k];

    // Record the average times for each kernel across the number of iterations.
    unsigned long long time_3a = 0;
    unsigned long long time_3b = 0;
    unsigned long long time_4a = 0;
    unsigned long long time_4b = 0;

    // We loop for 1000 iterations. 
    for(int iter = 0; iter < 1000; iter++) {
        // printf("Iteration %d\n", iter);

        // Reset the partial sums and numbers of points.
        memset(cluster_coordinate_sums, 0.0, k*m*sizeof(float));
        memset(num_points_in_cluster, 0, k*sizeof(int));
        
        ////// 3: Assign each point to its closest cluster.
        
        //// 3a: Get the distances between each point and cluster.
        unsigned long long st = rdtsc();
        for(int pt = 0; pt < n; pt++) {
            for(int cluster = 0; cluster < k; cluster++) {
                float dist = distance(data + m*pt, centroids + m*cluster, m);
                distances[k*pt + cluster] = dist;
            }
        }
        unsigned long long et = rdtsc();
        time_3a += et - st;

        //// 3b: Assign the point to its closest cluster.
        st = rdtsc();
        for(int pt = 0; pt < n; pt++) {
            // Check each cluster and see which one is the closest.
            int closest_cluster = -1;
            float best_distance = DBL_MAX;
            for(int cluster = 0; cluster < k; cluster++) {
                if(distances[k*pt + cluster] < best_distance) {
                    best_distance = distances[k*pt + cluster];
                    closest_cluster = cluster;
                }
            }

            // Assign the closest cluster to the point. 
            point_to_cluster[pt] = closest_cluster;
        }
        et = rdtsc();
        time_3b += et - st;
        
        ////// 4: Update each cluster's centroid to the mean of all points assigned to it.
        
        // To do this in O(n), we can simply loop through the points 
        // and get a running sum of each cluster's coordinates, and then divide 
        // each coordinate by the final numbers of points for each cluster to 
        // get the mean for each cluster.
        
        //// 4a: Get the sum of points for each cluster.
        st = rdtsc();
        for(int pt = 0; pt < n; pt++) {
            // Figure out which cluster the point is in.
            int cluster = point_to_cluster[pt];
            // Update that cluster's number of points.
            num_points_in_cluster[cluster]++;
            // Update that cluster's sum of coordinates with this point.
            for(int i = 0; i < m; i++) {
                cluster_coordinate_sums[m*cluster + i] += data[m*pt + i];
            }
        }
        et = rdtsc();
        time_4a += et - st;
        
        //// 4b: Divide the sum of points for each cluster by the number of points in the cluster 
        // to get the average of the points in the cluster (the centroid). 
        // Assign each cluster to be its average.
        st = rdtsc();
        for(int cluster = 0; cluster < k; cluster++) {
            // If the cluster has points in it then its mean becomes the average of the points.
            if(num_points_in_cluster[cluster] > 0) {
                for(int i = 0; i < m; i++) {
                    centroids[m*cluster + i] = cluster_coordinate_sums[m*cluster + i] / num_points_in_cluster[cluster];
                }
            } else {
                // If the cluster doesn't have points in it then initialize it randomly again.
                int random_idx = rand() % n;
                for(int i = 0; i < m*k; i++) {
                    centroids[i] = data[m*random_idx + i]; 
                }
            }
        }
        et = rdtsc();
        time_4b += et - st;
    }
        
    
    printf("Average cycles taken total on kernel 3a: %f\n", CPU_FREQ_SCALE * ((float) (time_3a) / 1000.0));
    printf("Average cycles taken total on kernel 3b: %f\n", CPU_FREQ_SCALE * ((float) (time_3b) / 1000.0));
    printf("Average cycles taken total on kernel 4a: %f\n", CPU_FREQ_SCALE * ((float) (time_4a) / 1000.0));
    printf("Average cycles taken total on kernel 4b: %f\n", CPU_FREQ_SCALE * ((float) (time_4b) / 1000.0));

    // Given that the dataset has k clusters and n points in m dimensions:
    // Kernel 3a does a subtract and FMA for each dimension in each point and each cluster. 
    // Thus, there are 2*mnk FLOPs done in 3a.
    // Kernel 3b does a compare for each point and each cluster. 
    // Thus, are there nk FLOPs done in 3b.
    // Kernel 4a does an add for each dimension in each point. 
    // Thus, there are mn FLOPs done in 4a.
    // Kernel 4b does a division for each dimension in each cluster. 
    // Thus, there are mk FLOPs done in 4b.
    printf("Throughput in kernel 3a: %f\n", (2*m*n*k) / (CPU_FREQ_SCALE * ((float) (time_3a) / 1000.0)));
    printf("Throughput in kernel 3b: %f\n", (n*k) / (CPU_FREQ_SCALE * ((float) (time_3b) / 1000.0)));
    printf("Throughput in kernel 4a: %f\n", (m*n) / (CPU_FREQ_SCALE * ((float) (time_4a) / 1000.0)));
    printf("Throughput in kernel 4b: %f\n", (m*k) / (CPU_FREQ_SCALE * ((float) (time_4b) / 1000.0)));
}


/*
 * Test k-means with 6 2-D points. The test dataset is illustrated in the 
 * scikit-learn k-means documentation, at 
 * https://scikit-learn.org/stable/modules/generated/sklearn.cluster.KMeans.html 
 */
void test_basic() {
    printf("Basic test on the sklearn toy dataset:\n");
    // Allocate 12 floats for the dataset.
    float data[12]; 
    data[0] = 1.0;
    data[1] = 2.0;
    data[2] = 1.0;
    data[3] = 4.0;
    data[4] = 1.0;
    data[5] = 0.0;
    data[6] = 10.0;
    data[7] = 2.0;
    data[8] = 10.0;
    data[9] = 4.0;
    data[10] = 10.0;
    data[11] = 0.0;

    // Allocate space for 2 centroids.
    float centroids[4];

    // Note that I'm passing stack-allocated memory, but we're guaranteed 
    // that data and centroids are valid memory for the duration of kmeans, 
    // since we're calling kmeans and know its memory guarantees.
    kmeans(data, 6, 2, 2, centroids);

    // Print the centroids. They could be in any order, but should be (10, 2) and (1, 2).
    printf("\tThe centroids should be (10,2) and (1,2).\n");
    printf("\tThe first centroid is (%lf,%lf).\n", centroids[0], centroids[1]);
    printf("\tThe second centroid is (%lf,%lf).\n", centroids[2], centroids[3]);
    printf("Basic test completed.\n");
}

/*
 * Test k-means with 5 4-D points. Has three points as a cluster near (1,1,1,1) and two as a cluster near (5,5,5,5).
 */
void test_4D() {
    printf("4-D test:\n");
    // Allocate 20 floats for the dataset.
    float data[5 * 4]; 
    data[0] = 1.0;
    data[1] = 1.0;
    data[2] = 1.0;
    data[3] = 1.0;
    data[4] = 0.5;
    data[5] = 0.5;
    data[6] = 0.5;
    data[7] = 0.5;
    data[8] = 1.1;
    data[9] = 2.0;
    data[10] = 0.8;
    data[11] = 0.9;
    data[12] = 4.0;
    data[13] = 4.21122;
    data[14] = 6.0;
    data[15] = 5.1;
    data[16] = 4.8;
    data[17] = 3.6;
    data[18] = 7.2;
    data[19] = 4.92;

    // Allocate space for 2 4-dimensional centroids.
    float centroids[2 * 4];

    // Note that I'm passing stack-allocated memory, but we're guaranteed 
    // that data and centroids are valid memory for the duration of kmeans, 
    // since we're calling kmeans and know its memory guarantees.
    kmeans(data, 5, 4, 2, centroids);

    // Print the centroids. They could be in any order, but should be (10, 2) and (1, 2).
    printf("\tThe centroids should be around (1,1,1,1) and (5,5,5,5).\n");
    printf("\tThe first centroid is (%lf,%lf,%lf,%lf).\n", centroids[0], centroids[1], centroids[2], centroids[3]);
    printf("\tThe second centroid is (%lf,%lf,%lf,%lf).\n", centroids[4], centroids[5], centroids[6], centroids[7]);
    printf("4D test completed.\n");
}

/*
 * Test the Euclidean distance function.
 */
void test_distance() {
    float pt1[2];
    float pt2[2];
    pt1[0] = 1.0;
    pt1[1] = 5.0;
    pt2[0] = 2.0;
    pt2[1] = 6.0;
    printf("The distance between (1,5) and (2,6) should be around sqrt(2).\n");
    printf("The distance is: %lf\n", distance(pt1, pt2, 2));
}

int main() {
    // printf("Testing Euclidean distance...\n");
    // test_distance();
    printf("Timing unoptimized k-means. Note that since k-means initializes clusters randomly, it might return incorrect clusters sometimes.\n");
    test_basic();

    return 0;
}
