import numpy as np
from sklearn.cluster import KMeans
from time import time

X = np.array([[1, 2], [1, 4], [1, 0], [10, 2], [10, 4], [10, 0]])
t1 = time()
kmeans = KMeans(n_clusters=2, random_state=0).fit(X)
t2 = time()

# The elapsed time is the number of seconds that passed to fit k-means
# on the data.
# The elapsed cycles is the clock time of the processor * the number of seconds.
elapsed_time = t2 - t1
elapsed_cycles = 2.8 * (10 ** 9) * elapsed_time
print(f"The sklearn example took {elapsed_cycles} cycles.")
print(f"K-means found clusters {kmeans.cluster_centers_}.")

X = np.array([[1,1,1,1], [0.5,0.5,0.5,0.5], [1.1,2.0,0.8,0.9], [4.0,4.21122,6.0,5.1], [4.8,3.6,7.2,4.92]])
t1 = time()
kmeans = KMeans(n_clusters=2, random_state=0).fit(X)
t2 = time()

# The elapsed time is the number of seconds that passed to fit k-means
# on the data.
# The elapsed cycles is the clock time of the processor * the number of seconds.
elapsed_time = t2 - t1
elapsed_cycles = 2.8 * (10 ** 9) * elapsed_time
print(f"The 4-D data took {elapsed_cycles} cycles.")
print(f"K-means found clusters {kmeans.cluster_centers_}.")
