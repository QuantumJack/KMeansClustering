# 18645-Fast-KMeans

Fast K-Means using AVX SIMD Instructions, for 18-645 Fall 2021

This repo contains files for a semester-long project to implement k-means that can run near the theoretical peak throughput on ECE lab machine 10.

## Files

### K-Means implementations

Each of the ```kmeans*.c``` files contains an implementation of kmeans and a test that uses the k-means implementation to find 8 clusters on a configurable number of 8-D points. You can change the number of points in the test case for any of the implementations by modifying the ```num_of_data``` variable in the ```main``` function of the file.

Additionally, ```kmeans_starter.c```, ```kmeans_simd.c``` and ```kmeans_simd_parallel.c``` have a test that finds 8 clusters on a configurable number of points in a configurable number of dimensions. This additional test was meant to both verify correctness and provide a plot that shows OpenMP's speedup as the dimensions increase in the input dataset. You change the number of dimensions in the test case for these three files by modifying the ```m``` variable in the ```main``` function of these files.

#### Baseline implementations

```kmeans_starter.c``` contains the baseline, naive implementation of k-means.

```kmeans_unoptimized_kernels_timed.c``` contains the first draft of C baseline code and tests. It also benchmarks each of the naive kernels, for baseline throughput numbers.


#### SIMD kernels
 
```kmeans_simd.c``` contains the SIMD implementation of k-means. It has all four SIMD kernels.

```kmeans_3a.c``` contains k-means with the SIMD implementation of kernel 3a, and the rest of the kernels naively implemented. It also will output the throughput of SIMD kernel 3a. See the comments in the code for the calculation.

```kmeans_3b.c``` contains k-means with the SIMD implementation of kernel 3b, and the rest of the kernels naively implemented. It also will output the throughput of SIMD kernel 3b. See the comments in the code for the calculation.

```kmeans_4a.c``` contains k-means with the SIMD implementation of kernel 4a, and the rest of the kernels naively implemented. It also will output the throughput of SIMD kernel 4a. See the comments in the code for the calculation.

```kmeans_4b.c``` contains k-means with the SIMD implementation of kernel 4b, and the rest of the kernels naively implemented. It also will output the throughput of SIMD kernel 4b. See the comments in the code for the calculation.


#### SIMD kernels with OpenMP Parallelization

```kmeans_simd_parallel.c``` contains the SIMD implementation of k-means with additional OpenMP parallelization. It has all four parallelized SIMD kernels.

```kmeans_3a_parallel.c``` contains k-means with the SIMD implementation of kernel 3a with additional OpenMP parallelization, and the rest of the kernels naively implemented. It also will output the throughput of SIMD kernel 3a. See the comments in the code for the calculation.

```kmeans_3b_parallel.c``` contains k-means with the SIMD implementation of kernel 3b with additional OpenMP parallelization, and the rest of the kernels naively implemented. It also will output the throughput of SIMD kernel 3b. See the comments in the code for the calculation.

```kmeans_4a_parallel.c``` contains k-means with the SIMD implementation of kernel 4a with additional OpenMP parallelization, and the rest of the kernels naively implemented. It also will output the throughput of SIMD kernel 4a. See the comments in the code for the calculation.

```kmeans_4b_parallel.c``` contains k-means with the SIMD implementation of kernel 4b with additional OpenMP parallelization, and the rest of the kernels naively implemented. It also will output the throughput of SIMD kernel 4b. See the comments in the code for the calculation.

### Other files

```transpose_8x8_simd.c``` contains code which contains a proof-of-concept of SIMD matrix transposition on an 8x8 matrix of floats using only shuffles and permutes in SIMD registers. It also contains a test for the SIMD matrix transpose.


## Compilation

To compile any of the ```<name>.c``` files into a command-line executable, type 
```
make <name>
```

This will put an executable called ```<name>``` onto the command-line, which can be run with 
```
./<name>
```


For example, to compile and run the SIMD k-means function and test from the file ```kmeans_simd.c``` into a command-line executable, type 
```
make kmeans_simd; ./kmeans_simd
```

To clean up all executables, run
```
make clean;
```
